# RaceShop

How to run :

```
> docker build . -t local/race_shop
> docker run --name race_shop -it --rm -p 1002:1002 local/race_shop
```

How to attack :

```
> python3 attack.py
```